class SubjectModel {
  String subName;
  String subCode;

  SubjectModel(this.subName, this.subCode);
}
