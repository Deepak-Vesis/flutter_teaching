import 'package:calculator/learn_getx/quiz_home_page_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class QuizHomePage extends StatelessWidget {
  const QuizHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    var controller = Get.put(QuizHomePageController());

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text.rich(
          TextSpan(
            text: 'Quiz', // Base text for the TextSpan
            style: TextStyle(fontSize: 20, color: Colors.white), // Base style
            children: <TextSpan>[
              TextSpan(
                text: 'Zone', // Child TextSpan
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.yellow,
                ), // Overrides base style
              ),
            ],
          ),
        ),
        leading: Icon(Icons.menu, color: Colors.white, size: 30),
        backgroundColor: Colors.black,
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Icon(Icons.notifications_outlined),
          ),
        ],
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.black, Colors.indigo], // Define the colors
            begin: Alignment.topCenter, // Starting point of the gradient
            end: Alignment.bottomCenter, // Ending point of the gradient
            // Optional: control color distribution
          ),
        ),
        child: ListView(
          children: [
            SizedBox(height: 40),
            Text(
              "Hi, Students",
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white, fontSize: 24),
            ),
            SizedBox(height: 10),
            Text(
              "Check your knowledge",
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white, fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
